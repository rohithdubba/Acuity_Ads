package acutiyads;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AcuityHomePage {
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Solutions')]/..")
	WebElement solutions;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Insights')]/..")
	WebElement insights;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'News')]/..")
	WebElement news;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Company')]/..")
	WebElement company;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'illumin')]")
	WebElement illumin;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Blog')]")
	WebElement Blog;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Press')]")
	WebElement Press;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'About Us')]")
	WebElement AboutUs;
	WebDriver driver;
	public AcuityHomePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}

	public void clickSolution()
	{
		solutions.click();
	}
	public void clickInsights()
	{
		insights.click();
	}
	public void clickNews()
	{
		solutions.click();
	}
	public void clickCompany()
	{
		company.click();
	}
	
	public boolean verifySolutions()
	{
		sleep();
		return illumin.isDisplayed();
	}
	public boolean verifyInsights()
	{
		sleep();
		return Blog.isDisplayed();
	}
	public boolean verifyNews()
	{
		sleep();
		return Press.isDisplayed();
	}
	public boolean verifyCompany()
	{
		return AboutUs.isDisplayed();
	}
	
	public void sleep()
	{
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
