package acutiyads;

import org.testng.annotations.Test;

import junit.framework.Assert;

public class EndTests extends BaseClass{
	AcuityHomePage acuityHomePage;
	
//	@Test
	public void ValidateSolutions()
	{
		acuityHomePage=new AcuityHomePage(driver);
		acuityHomePage.clickSolution();
		Assert.assertTrue(acuityHomePage.verifySolutions());
	}
	@Test
	public void ValidateInsights()
	{
		acuityHomePage=new AcuityHomePage(driver);
		acuityHomePage.clickInsights();
		Assert.assertTrue(acuityHomePage.verifyInsights());
	}
//	@Test
	public void ValidateNews()
	{
		acuityHomePage=new AcuityHomePage(driver);
		acuityHomePage.clickNews();
		Assert.assertTrue(acuityHomePage.verifyNews());
	}
	@Test
	public void ValidateCompany()
	{
		acuityHomePage=new AcuityHomePage(driver);
		acuityHomePage.clickCompany();
		Assert.assertTrue(acuityHomePage.verifyCompany());
	}

}